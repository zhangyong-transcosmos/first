import request from '@/utils/request'

export var upload = process.env.BASE_API + '/template/upload'
